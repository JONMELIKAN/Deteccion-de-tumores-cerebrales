package com.example.ddt;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Manejar el retraso para volver a MainActivity1
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Volver a MainActivity1
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
                finish(); // Cierra MainActivity2 para que no se quede en la pila
            }
        }, 4000); // 4000 ms = 4 segundos
    }
}

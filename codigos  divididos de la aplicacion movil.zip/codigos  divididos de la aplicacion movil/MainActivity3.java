package com.example.ddt;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        ImageView resultImageView = findViewById(R.id.resultImageView);
        TextView resultTextView = findViewById(R.id.resultTextView);
        TextView detailsTextView = findViewById(R.id.detailsTextView);
        Button backButton = findViewById(R.id.backButton);

        // Obtener datos del intent
        Intent intent = getIntent();
        String resultText = intent.getStringExtra("RESULT_TEXT");
        String imageUriString = intent.getStringExtra("IMAGE_URI");
        String detailsText = intent.getStringExtra("DETAILS_TEXT");

        // Verificar si el URI de la imagen es nulo
        if (imageUriString != null && !imageUriString.isEmpty()) {
            Uri imageUri = Uri.parse(imageUriString);
            resultImageView.setImageURI(imageUri);
        }

        resultTextView.setText(resultText);
        detailsTextView.setText(detailsText);

        // Cambiar color de texto según el resultado
        if (resultText != null && resultText.contains("Tumor detectado")) {
            resultTextView.setTextColor(Color.RED);
        } else {
            resultTextView.setTextColor(Color.GREEN);
        }

        detailsTextView.setTextColor(Color.WHITE);  // Cambiar color de las probabilidades y explicación a blanco

        backButton.setOnClickListener(v -> {
            // Regresar a MainActivity
            Intent backIntent = new Intent(MainActivity3.this, MainActivity.class);
            startActivity(backIntent);
            finish();
        });
    }
}

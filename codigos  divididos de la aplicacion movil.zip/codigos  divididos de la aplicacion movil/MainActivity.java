package com.example.ddt;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.tensorflow.lite.Interpreter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private static final int SELECT_IMAGE = 1;
    private ImageView imageView;
    private Bitmap selectedImage;
    private Interpreter tflite;
    private ProgressBar progressBar;

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        progressBar = findViewById(R.id.progressBar);
        Button selectImageButton = findViewById(R.id.selectImageButton);
        Button detectButton = findViewById(R.id.detectButton);

        try {
            tflite = new Interpreter(loadModelFile());
            Log.d(TAG, "Modelo TFLite cargado correctamente.");
        } catch (IOException e) {
            Log.e(TAG, "Error al cargar el modelo TFLite.", e);
            Toast.makeText(this, "Error al cargar el modelo TFLite.", Toast.LENGTH_LONG).show();
        }

        selectImageButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, SELECT_IMAGE);
        });

        detectButton.setOnClickListener(v -> {
            if (selectedImage != null) {
                progressBar.setVisibility(View.VISIBLE);
                new Thread(() -> {
                    try {
                        Bitmap resizedImage = Bitmap.createScaledBitmap(selectedImage, 128, 128, true);
                        float tumorProbability = runInference(resizedImage);
                        String resultText = (tumorProbability > 0.5) ? "Tumor detectado" : "No se detectó tumor";
                        Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                        intent.putExtra("RESULT_TEXT", resultText);
                        Uri imageUri = getImageUri(selectedImage);
                        if (imageUri != null) {
                            intent.putExtra("IMAGE_URI", imageUri.toString());
                        } else {
                            Log.e(TAG, "No se pudo obtener el URI de la imagen");
                        }
                        intent.putExtra("DETAILS_TEXT", "Probabilidad de Tumor: " + (tumorProbability * 100) + "%\nProbabilidad de No Tumor: " + ((1 - tumorProbability) * 100) + "%");
                        intent.putExtra("TUMOR_PROBABILITY", tumorProbability);
                        startActivity(intent);
                    } catch (Exception e) {
                        Log.e(TAG, "Error al realizar la inferencia.", e);
                        runOnUiThread(() -> Toast.makeText(this, "Error durante la detección.", Toast.LENGTH_LONG).show());
                    } finally {
                        runOnUiThread(() -> progressBar.setVisibility(View.GONE));
                    }
                }).start();
            } else {
                Toast.makeText(this, "Por favor, seleccione una imagen primero.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SELECT_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            try {
                selectedImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                imageView.setImageBitmap(selectedImage);
                Log.d(TAG, "Imagen seleccionada correctamente.");
            } catch (IOException e) {
                Log.e(TAG, "Error al seleccionar la imagen.", e);
                Toast.makeText(this, "Error al seleccionar la imagen.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private ByteBuffer loadModelFile() throws IOException {
        try (FileChannel fileChannel = new FileInputStream(getAssets().openFd("model.tflite").getFileDescriptor()).getChannel()) {
            long startOffset = getAssets().openFd("model.tflite").getStartOffset();
            long declaredLength = getAssets().openFd("model.tflite").getLength();
            ByteBuffer buffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength).order(ByteOrder.nativeOrder());
            return buffer;
        }
    }

    private float runInference(Bitmap bitmap) {
        ByteBuffer inputBuffer = convertBitmapToByteBuffer(bitmap);
        float[][] output = new float[1][1];
        try {
            tflite.run(inputBuffer, output);
        } catch (Exception e) {
            Log.e(TAG, "Error en runInference: ", e);
            return -1; // Valor de error
        }
        return output[0][0];
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer buffer = ByteBuffer.allocateDirect(4 * 128 * 128 * 3).order(ByteOrder.nativeOrder());
        int[] intValues = new int[128 * 128];
        bitmap.getPixels(intValues, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        int pixel = 0;
        for (int i = 0; i < 128; ++i) {
            for (int j = 0; j < 128; ++j) {
                int val = intValues[pixel++];
                buffer.putFloat(((val >> 16) & 0xFF) / 255.0f);
                buffer.putFloat(((val >> 8) & 0xFF) / 255.0f);
                buffer.putFloat((val & 0xFF) / 255.0f);
            }
        }
        return buffer;
    }

    private Uri getImageUri(Bitmap bitmap) {
        if (bitmap == null) {
            Log.e(TAG, "Bitmap es nulo en getImageUri()");
            return null;
        }
        try {
            // Guardar la imagen en el almacenamiento interno
            File file = new File(getFilesDir(), "image.jpg");
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();

            // Retornar URI para el archivo
            return Uri.fromFile(file);
        } catch (IOException e) {
            Log.e(TAG, "Error al insertar imagen en getImageUri()", e);
            return null;
        }
    }
}
